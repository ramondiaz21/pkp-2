# Press Settings

Configure basic details about the press, including contact information, policies, author guidelines, sponsor relationships and more. You can also add Series and Categories to your catalog from this settings page.
